﻿namespace Pocetni
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.imgBB8 = new System.Windows.Forms.PictureBox();
            this.imgZmijica = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.imgBB8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgZmijica)).BeginInit();
            this.SuspendLayout();
            // 
            // imgBB8
            // 
            this.imgBB8.Image = ((System.Drawing.Image)(resources.GetObject("imgBB8.Image")));
            this.imgBB8.Location = new System.Drawing.Point(333, 520);
            this.imgBB8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.imgBB8.Name = "imgBB8";
            this.imgBB8.Size = new System.Drawing.Size(100, 97);
            this.imgBB8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.imgBB8.TabIndex = 2;
            this.imgBB8.TabStop = false;
            this.imgBB8.Click += new System.EventHandler(this.imgBB8_Click);
            // 
            // imgZmijica
            // 
            this.imgZmijica.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("imgZmijica.BackgroundImage")));
            this.imgZmijica.Location = new System.Drawing.Point(667, 195);
            this.imgZmijica.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.imgZmijica.Name = "imgZmijica";
            this.imgZmijica.Size = new System.Drawing.Size(100, 65);
            this.imgZmijica.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.imgZmijica.TabIndex = 3;
            this.imgZmijica.TabStop = false;
            this.imgZmijica.Click += new System.EventHandler(this.imgZmijica_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(810, 589);
            this.Controls.Add(this.imgZmijica);
            this.Controls.Add(this.imgBB8);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Igrice Bo i Vivi";
            ((System.ComponentModel.ISupportInitialize)(this.imgBB8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgZmijica)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox imgBB8;
        private System.Windows.Forms.PictureBox imgZmijica;
    }
}

