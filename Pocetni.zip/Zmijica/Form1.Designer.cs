﻿namespace Zmijica
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.txtPoeni1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.nivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lakToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.srednjiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tezakToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chkRaste = new System.Windows.Forms.CheckBox();
            this.chkProlazi = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.chkPrepreke = new System.Windows.Forms.CheckBox();
            this.txtTrajanje = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.cbxTipIgre = new System.Windows.Forms.ComboBox();
            this.txtBrzina = new System.Windows.Forms.NumericUpDown();
            this.lblBrojZivota1 = new System.Windows.Forms.Label();
            this.chkIdeUKrug = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.chkSeSudara = new System.Windows.Forms.CheckBox();
            this.rbr1 = new System.Windows.Forms.RadioButton();
            this.rbr2 = new System.Windows.Forms.RadioButton();
            this.txtPoeni2 = new System.Windows.Forms.TextBox();
            this.lblBrojZivota2 = new System.Windows.Forms.Label();
            this.chkNaVreme = new System.Windows.Forms.CheckBox();
            this.txtVreme = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.txtSat = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTrajanje)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBrzina)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtVreme)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Gray;
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 18;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.Location = new System.Drawing.Point(40, 78);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 18;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(712, 708);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // txtPoeni1
            // 
            this.txtPoeni1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtPoeni1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPoeni1.Location = new System.Drawing.Point(776, 174);
            this.txtPoeni1.Name = "txtPoeni1";
            this.txtPoeni1.Size = new System.Drawing.Size(200, 44);
            this.txtPoeni1.TabIndex = 1;
            this.txtPoeni1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.korisnikPritisnuoDugmic);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button1.Location = new System.Drawing.Point(764, 78);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(200, 51);
            this.button1.TabIndex = 2;
            this.button1.Text = "START";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.start);
            this.button1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.korisnikPritisnuoDugmic);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(772, 146);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Pauza";
            this.label1.Visible = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nivoToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1348, 33);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // nivoToolStripMenuItem
            // 
            this.nivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lakToolStripMenuItem,
            this.srednjiToolStripMenuItem,
            this.tezakToolStripMenuItem});
            this.nivoToolStripMenuItem.Name = "nivoToolStripMenuItem";
            this.nivoToolStripMenuItem.Size = new System.Drawing.Size(61, 29);
            this.nivoToolStripMenuItem.Text = "Nivo";
            // 
            // lakToolStripMenuItem
            // 
            this.lakToolStripMenuItem.Name = "lakToolStripMenuItem";
            this.lakToolStripMenuItem.Size = new System.Drawing.Size(252, 30);
            this.lakToolStripMenuItem.Text = "Lak";
            this.lakToolStripMenuItem.Click += new System.EventHandler(this.lakToolStripMenuItem_Click);
            // 
            // srednjiToolStripMenuItem
            // 
            this.srednjiToolStripMenuItem.Name = "srednjiToolStripMenuItem";
            this.srednjiToolStripMenuItem.Size = new System.Drawing.Size(252, 30);
            this.srednjiToolStripMenuItem.Text = "Srednji";
            this.srednjiToolStripMenuItem.Click += new System.EventHandler(this.srednjiToolStripMenuItem_Click);
            // 
            // tezakToolStripMenuItem
            // 
            this.tezakToolStripMenuItem.Name = "tezakToolStripMenuItem";
            this.tezakToolStripMenuItem.Size = new System.Drawing.Size(252, 30);
            this.tezakToolStripMenuItem.Text = "Tezak";
            this.tezakToolStripMenuItem.Click += new System.EventHandler(this.tezakToolStripMenuItem_Click);
            // 
            // chkRaste
            // 
            this.chkRaste.AutoSize = true;
            this.chkRaste.Checked = true;
            this.chkRaste.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkRaste.Location = new System.Drawing.Point(1025, 118);
            this.chkRaste.Name = "chkRaste";
            this.chkRaste.Size = new System.Drawing.Size(124, 24);
            this.chkRaste.TabIndex = 5;
            this.chkRaste.Text = "Zmijica raste";
            this.chkRaste.UseVisualStyleBackColor = true;
            // 
            // chkProlazi
            // 
            this.chkProlazi.AutoSize = true;
            this.chkProlazi.Location = new System.Drawing.Point(1025, 159);
            this.chkProlazi.Name = "chkProlazi";
            this.chkProlazi.Size = new System.Drawing.Size(207, 24);
            this.chkProlazi.TabIndex = 6;
            this.chkProlazi.Text = "Zmijica prolazi kroz sebe";
            this.chkProlazi.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1021, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "Nivo";
            // 
            // chkPrepreke
            // 
            this.chkPrepreke.AutoSize = true;
            this.chkPrepreke.Location = new System.Drawing.Point(1025, 189);
            this.chkPrepreke.Name = "chkPrepreke";
            this.chkPrepreke.Size = new System.Drawing.Size(188, 24);
            this.chkPrepreke.TabIndex = 8;
            this.chkPrepreke.Text = "Pojavljuju se prepreke";
            this.chkPrepreke.UseVisualStyleBackColor = true;
            // 
            // txtTrajanje
            // 
            this.txtTrajanje.Location = new System.Drawing.Point(1025, 219);
            this.txtTrajanje.Name = "txtTrajanje";
            this.txtTrajanje.Size = new System.Drawing.Size(120, 26);
            this.txtTrajanje.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1151, 219);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 20);
            this.label3.TabIndex = 10;
            this.label3.Text = "Trajanje";
            // 
            // cbxTipIgre
            // 
            this.cbxTipIgre.FormattingEnabled = true;
            this.cbxTipIgre.Items.AddRange(new object[] {
            "Jabuka",
            "DveJabuke",
            "Razno"});
            this.cbxTipIgre.Location = new System.Drawing.Point(1025, 261);
            this.cbxTipIgre.Name = "cbxTipIgre";
            this.cbxTipIgre.Size = new System.Drawing.Size(185, 28);
            this.cbxTipIgre.TabIndex = 11;
            // 
            // txtBrzina
            // 
            this.txtBrzina.Location = new System.Drawing.Point(1025, 305);
            this.txtBrzina.Name = "txtBrzina";
            this.txtBrzina.Size = new System.Drawing.Size(120, 26);
            this.txtBrzina.TabIndex = 12;
            // 
            // lblBrojZivota1
            // 
            this.lblBrojZivota1.AutoSize = true;
            this.lblBrojZivota1.BackColor = System.Drawing.Color.MistyRose;
            this.lblBrojZivota1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBrojZivota1.Location = new System.Drawing.Point(778, 233);
            this.lblBrojZivota1.Name = "lblBrojZivota1";
            this.lblBrojZivota1.Size = new System.Drawing.Size(177, 37);
            this.lblBrojZivota1.TabIndex = 13;
            this.lblBrojZivota1.Text = "Broj zivota";
            // 
            // chkIdeUKrug
            // 
            this.chkIdeUKrug.AutoSize = true;
            this.chkIdeUKrug.Location = new System.Drawing.Point(1025, 351);
            this.chkIdeUKrug.Name = "chkIdeUKrug";
            this.chkIdeUKrug.Size = new System.Drawing.Size(106, 24);
            this.chkIdeUKrug.TabIndex = 14;
            this.chkIdeUKrug.Text = "Ide u krug";
            this.chkIdeUKrug.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1151, 311);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 20);
            this.label4.TabIndex = 15;
            this.label4.Text = "Brzina";
            // 
            // chkSeSudara
            // 
            this.chkSeSudara.AutoSize = true;
            this.chkSeSudara.Location = new System.Drawing.Point(1025, 381);
            this.chkSeSudara.Name = "chkSeSudara";
            this.chkSeSudara.Size = new System.Drawing.Size(301, 24);
            this.chkSeSudara.TabIndex = 16;
            this.chkSeSudara.Text = "Zmijica se sudara sa drugom zmijicom";
            this.chkSeSudara.UseVisualStyleBackColor = true;
            // 
            // rbr1
            // 
            this.rbr1.AutoSize = true;
            this.rbr1.Checked = true;
            this.rbr1.Location = new System.Drawing.Point(1025, 470);
            this.rbr1.Name = "rbr1";
            this.rbr1.Size = new System.Drawing.Size(116, 24);
            this.rbr1.TabIndex = 17;
            this.rbr1.TabStop = true;
            this.rbr1.Text = "Jedan igrac";
            this.rbr1.UseVisualStyleBackColor = true;
            // 
            // rbr2
            // 
            this.rbr2.AutoSize = true;
            this.rbr2.Location = new System.Drawing.Point(1025, 500);
            this.rbr2.Name = "rbr2";
            this.rbr2.Size = new System.Drawing.Size(109, 24);
            this.rbr2.TabIndex = 18;
            this.rbr2.Text = "Dva igraca";
            this.rbr2.UseVisualStyleBackColor = true;
            // 
            // txtPoeni2
            // 
            this.txtPoeni2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtPoeni2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPoeni2.Location = new System.Drawing.Point(776, 294);
            this.txtPoeni2.Name = "txtPoeni2";
            this.txtPoeni2.Size = new System.Drawing.Size(200, 44);
            this.txtPoeni2.TabIndex = 19;
            // 
            // lblBrojZivota2
            // 
            this.lblBrojZivota2.AutoSize = true;
            this.lblBrojZivota2.BackColor = System.Drawing.Color.MistyRose;
            this.lblBrojZivota2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBrojZivota2.Location = new System.Drawing.Point(778, 355);
            this.lblBrojZivota2.Name = "lblBrojZivota2";
            this.lblBrojZivota2.Size = new System.Drawing.Size(177, 37);
            this.lblBrojZivota2.TabIndex = 20;
            this.lblBrojZivota2.Text = "Broj zivota";
            // 
            // chkNaVreme
            // 
            this.chkNaVreme.AutoSize = true;
            this.chkNaVreme.Location = new System.Drawing.Point(1025, 411);
            this.chkNaVreme.Name = "chkNaVreme";
            this.chkNaVreme.Size = new System.Drawing.Size(102, 24);
            this.chkNaVreme.TabIndex = 21;
            this.chkNaVreme.Text = "Na vreme";
            this.chkNaVreme.UseVisualStyleBackColor = true;
            // 
            // txtVreme
            // 
            this.txtVreme.Location = new System.Drawing.Point(1025, 438);
            this.txtVreme.Name = "txtVreme";
            this.txtVreme.Size = new System.Drawing.Size(120, 26);
            this.txtVreme.TabIndex = 22;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1148, 440);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 20);
            this.label5.TabIndex = 23;
            this.label5.Text = "Vreme";
            // 
            // txtSat
            // 
            this.txtSat.Location = new System.Drawing.Point(776, 411);
            this.txtSat.Name = "txtSat";
            this.txtSat.Size = new System.Drawing.Size(100, 26);
            this.txtSat.TabIndex = 24;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1348, 944);
            this.Controls.Add(this.txtSat);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtVreme);
            this.Controls.Add(this.chkNaVreme);
            this.Controls.Add(this.lblBrojZivota2);
            this.Controls.Add(this.txtPoeni2);
            this.Controls.Add(this.rbr2);
            this.Controls.Add(this.rbr1);
            this.Controls.Add(this.chkSeSudara);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.chkIdeUKrug);
            this.Controls.Add(this.lblBrojZivota1);
            this.Controls.Add(this.txtBrzina);
            this.Controls.Add(this.cbxTipIgre);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtTrajanje);
            this.Controls.Add(this.chkPrepreke);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.chkProlazi);
            this.Controls.Add(this.chkRaste);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtPoeni1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Zmijica";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.korisnikPritisnuoDugmic);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTrajanje)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBrzina)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtVreme)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox txtPoeni1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem nivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lakToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem srednjiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tezakToolStripMenuItem;
        private System.Windows.Forms.CheckBox chkRaste;
        private System.Windows.Forms.CheckBox chkProlazi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox chkPrepreke;
        private System.Windows.Forms.NumericUpDown txtTrajanje;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbxTipIgre;
        private System.Windows.Forms.NumericUpDown txtBrzina;
        private System.Windows.Forms.Label lblBrojZivota1;
        private System.Windows.Forms.CheckBox chkIdeUKrug;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox chkSeSudara;
        private System.Windows.Forms.RadioButton rbr1;
        private System.Windows.Forms.RadioButton rbr2;
        private System.Windows.Forms.TextBox txtPoeni2;
        private System.Windows.Forms.Label lblBrojZivota2;
        private System.Windows.Forms.CheckBox chkNaVreme;
        private System.Windows.Forms.NumericUpDown txtVreme;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtSat;
    }
}

