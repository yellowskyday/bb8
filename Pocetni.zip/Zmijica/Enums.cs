﻿

using System.Collections.Generic;
using System.Linq;

namespace Zmijica
{    public enum Smer
    {
        Gore,
        Dole,
        Levo,
        Desno
    }

    public enum Efekat
    {
        DodajPoene,
        DodajZivot,
        OduzmiZivot,
        UkloniPrepreku
    }

    public enum PonasanjePremaVocu
    {
        Jabuka,
        DveJabuke,
        Razno
    }

}
