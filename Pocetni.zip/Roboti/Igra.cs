﻿using Roboti.Podloge;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roboti
{
    public class Igra
    {

        #region Fields

        PokretnaTraka pokretnaTraka;
        int brojZivota;
        int trenutnaPozicija;
        private Kraj kraj;
        public Kraj Kraj { get => kraj; }

        #endregion

        #region Constructors
        public Igra()
        {
            pokretnaTraka = new PokretnaTraka();
            brojZivota = 1;
            trenutnaPozicija = 0;
        }

        #endregion

        #region Methods

        public void TikTak(Smer smer, Udar udar)
        {
            
        }

        #endregion

        #region Private Methods

        #endregion

    }
}
