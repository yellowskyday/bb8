﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roboti.Podloge
{
    public class PokretnaTraka
    {
        List<Podloga> podloge = new List<Podloga>();
        public PokretnaTraka()
        {
            for (int i = 0; i < 50; i++)
            {
                int broj = (new Random()).Next(0, 3);
                if (broj == 0)
                    podloge.Add(new Trava());
                if (broj == 1)
                    podloge.Add(new Kutija());
                if (broj == 2)
                    podloge.Add(new Oblak());
            }
            podloge.Add(new KutijaR2D2());
        }
    }
}
